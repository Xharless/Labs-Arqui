Datos personales:
    	- Paralelo: 200

	- Nombre: Daniel Maturana
	- ROL USM: 202173575-5

   	- Nombre: Carlos Arévalo
        - ROL USM: 202173501-1

Detalles del programa: 
	- Se utilizó Logisim 2.7.1
	- Se considerará que al llegar al estado 15, pasará al estado 0.
	- Se utilizó los valores del display de 7 bits según el apunte.
	- Deberá ingresar el input en el pin del circuito "main", está etiquetado como "input".
	- Primero, usando la "herramienta de cambio" ingresará el input.
	- Segundo, en la parte superior seleccione "Simular" y "Activar Reloj". Comenzará a mostrar los valores.
	- Tercero, para detenerlo seleccione otra vez "Activar Reloj" y luego "Resetear Simulación".

Informe:
	- Contiene los mapas de Karnough correspondientes al de salida y cambios de estado, para este último se utilizó Flip Flop D.
	- Los bits de salida son según el apunte.